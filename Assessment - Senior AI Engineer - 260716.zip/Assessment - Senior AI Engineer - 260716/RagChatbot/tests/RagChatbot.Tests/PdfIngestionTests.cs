using RagChatbot.Api.Ingestion;

namespace RagChatbot.Tests;

public class PdfIngestionTests
{
    private static readonly string PdfPath = Path.Combine(
        AppContext.BaseDirectory, "Data", "Microsoft-Copilot-Studio-Licensing-Guide.pdf");

    [Fact]
    public void Licensing_guide_is_extracted_and_chunked_with_page_numbers()
    {
        var pages = new PdfTextExtractor().Extract(PdfPath);
        var chunks = new RecursiveTextSplitter(1000, 150).Split(pages);

        Assert.NotEmpty(pages);
        Assert.True(chunks.Count > pages.Count);
        Assert.All(chunks, c => Assert.True(c.Text.Length <= 1000 && c.Page > 0));
        Assert.Contains(chunks, c => c.Text.Contains("Copilot Credit", StringComparison.OrdinalIgnoreCase));
    }
}
