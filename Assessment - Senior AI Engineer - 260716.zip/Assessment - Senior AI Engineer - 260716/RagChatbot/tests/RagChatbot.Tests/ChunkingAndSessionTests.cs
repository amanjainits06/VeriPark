using RagChatbot.Api.Chat;
using RagChatbot.Api.Ingestion;

namespace RagChatbot.Tests;

public class RecursiveTextSplitterTests
{
    [Fact]
    public void Chunks_never_exceed_chunk_size()
    {
        var text = string.Join("\n\n", Enumerable.Range(0, 50).Select(i => $"Paragraph {i}. " + new string('x', 120)));
        var chunks = new RecursiveTextSplitter(500, 80).Split(text);

        Assert.True(chunks.Count > 1);
        Assert.All(chunks, c => Assert.True(c.Length <= 500));
    }

    [Fact]
    public void Consecutive_chunks_overlap()
    {
        var sentences = Enumerable.Range(0, 60).Select(i => $"Sentence number {i} says something. ");
        var chunks = new RecursiveTextSplitter(300, 100).Split(string.Concat(sentences));

        for (var i = 1; i < chunks.Count; i++)
        {
            var firstSentenceOfNext = chunks[i].Split(". ")[0];
            Assert.Contains(firstSentenceOfNext, chunks[i - 1]);
        }
    }

    [Fact]
    public void Text_without_separators_is_hard_cut()
    {
        var chunks = new RecursiveTextSplitter(100, 0).Split(new string('a', 350));
        Assert.Equal(4, chunks.Count);
    }

    [Fact]
    public void Page_numbers_are_preserved()
    {
        var pages = new[] { new PageText(3, "Alpha."), new PageText(7, "Beta.") };
        var chunks = new RecursiveTextSplitter(100, 10).Split(pages);

        Assert.Equal([3, 7], chunks.Select(c => c.Page));
        Assert.Equal([0, 1], chunks.Select(c => c.Index));
    }

    [Fact]
    public void Blank_text_yields_no_chunks() =>
        Assert.Empty(new RecursiveTextSplitter(100, 10).Split("   "));

    [Fact]
    public void Overlap_must_be_smaller_than_chunk_size() =>
        Assert.Throws<ArgumentOutOfRangeException>(() => new RecursiveTextSplitter(100, 100));
}

public class ChatSessionStoreTests
{
    [Fact]
    public void Oldest_turns_are_dropped_after_the_cap()
    {
        var session = new ChatSessionStore(10).GetOrCreate("s");
        for (var i = 1; i <= 12; i++) session.Add($"q{i}", $"a{i}");

        var turns = session.Snapshot();
        Assert.Equal(10, turns.Count);
        Assert.Equal("q3", turns[0].User);
        Assert.Equal("q12", turns[^1].User);
    }

    [Fact]
    public void Sessions_are_isolated_and_removable()
    {
        var store = new ChatSessionStore(10);
        store.GetOrCreate("a").Add("q", "a");

        Assert.Empty(store.GetOrCreate("b").Snapshot());
        Assert.True(store.Remove("a"));
        Assert.Empty(store.GetOrCreate("a").Snapshot());
    }
}
