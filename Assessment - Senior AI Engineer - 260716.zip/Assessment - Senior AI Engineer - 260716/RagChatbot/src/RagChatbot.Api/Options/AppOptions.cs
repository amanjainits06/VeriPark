using System.ComponentModel.DataAnnotations;

namespace RagChatbot.Api.Options;

public sealed class AzureOpenAIOptions
{
    public const string Section = "AzureOpenAI";

    [Required] public string Endpoint { get; set; } = "";

    // Optional: when empty, DefaultAzureCredential (Entra ID) is used.
    public string? ApiKey { get; set; }

    [Required] public string DeploymentName { get; set; } = "";
    [Required] public string EmbeddingDeploymentName { get; set; } = "";

    // Applies to reasoning models such as gpt-5-nano (minimal/low/medium/high).
    public string? ReasoningEffort { get; set; } = "low";
}

public sealed class QdrantOptions
{
    public const string Section = "Qdrant";

    [Required] public string Host { get; set; } = "localhost";
    [Range(1, 65535)] public int GrpcPort { get; set; } = 6334;
    [Required] public string Collection { get; set; } = "copilot_studio_licensing_guide";
}

public sealed class RagOptions
{
    public const string Section = "Rag";

    [Required] public string PdfPath { get; set; } = "Data/Microsoft-Copilot-Studio-Licensing-Guide.pdf";
    [Range(200, 4000)] public int ChunkSize { get; set; } = 1000;
    [Range(0, 1000)] public int ChunkOverlap { get; set; } = 150;
    [Range(1, 20)] public int TopK { get; set; } = 5;
    [Range(0, 1)] public double MinScore { get; set; } = 0.7;
    [Range(1, 100)] public int MaxHistoryTurns { get; set; } = 10;
    [Range(1, 64)] public int EmbeddingBatchSize { get; set; } = 16;
}
