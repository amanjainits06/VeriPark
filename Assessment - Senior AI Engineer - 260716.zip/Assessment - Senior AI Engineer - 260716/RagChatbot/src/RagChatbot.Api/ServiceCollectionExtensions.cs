using Azure.Identity;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.VectorData;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Connectors.Qdrant;
using Qdrant.Client;
using RagChatbot.Api.Chat;
using RagChatbot.Api.Ingestion;
using RagChatbot.Api.Options;
using RagChatbot.Api.Retrieval;

namespace RagChatbot.Api;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddRagChatbot(this IServiceCollection services, IConfiguration config)
    {
        services.AddOptions<AzureOpenAIOptions>().Bind(config.GetSection(AzureOpenAIOptions.Section))
            .ValidateDataAnnotations().ValidateOnStart();
        services.AddOptions<QdrantOptions>().Bind(config.GetSection(QdrantOptions.Section))
            .ValidateDataAnnotations().ValidateOnStart();
        services.AddOptions<RagOptions>().Bind(config.GetSection(RagOptions.Section))
            .ValidateDataAnnotations().ValidateOnStart();

        var ai = config.GetSection(AzureOpenAIOptions.Section).Get<AzureOpenAIOptions>() ?? new();
        var kernelBuilder = services.AddKernel();
        if (!string.IsNullOrWhiteSpace(ai.ApiKey))
        {
            kernelBuilder.AddAzureOpenAIChatCompletion(ai.DeploymentName, ai.Endpoint, ai.ApiKey);
            kernelBuilder.AddAzureOpenAIEmbeddingGenerator(ai.EmbeddingDeploymentName, ai.Endpoint, ai.ApiKey);
        }
        else
        {
            var credential = new DefaultAzureCredential();
            kernelBuilder.AddAzureOpenAIChatCompletion(ai.DeploymentName, ai.Endpoint, credential);
            kernelBuilder.AddAzureOpenAIEmbeddingGenerator(ai.EmbeddingDeploymentName, ai.Endpoint, credential);
        }

        services.AddSingleton(sp =>
        {
            var q = sp.GetRequiredService<IOptions<QdrantOptions>>().Value;
            return new QdrantClient(q.Host, q.GrpcPort);
        });
        services.AddSingleton<VectorStoreCollection<Guid, DocumentChunk>>(sp =>
        {
            var q = sp.GetRequiredService<IOptions<QdrantOptions>>().Value;
            var store = new QdrantVectorStore(sp.GetRequiredService<QdrantClient>(), ownsClient: false);
            return store.GetCollection<Guid, DocumentChunk>(q.Collection);
        });

        services.AddSingleton<PdfTextExtractor>();
        services.AddSingleton<IngestionService>();
        services.AddSingleton<IDocumentRetriever, QdrantDocumentRetriever>();
        services.AddSingleton(sp =>
            new ChatSessionStore(sp.GetRequiredService<IOptions<RagOptions>>().Value.MaxHistoryTurns));
        services.AddSingleton<RagChatService>();
        services.AddHostedService<IngestionHostedService>();

        return services;
    }
}

public sealed class IngestionHostedService(IngestionService ingestion, ILogger<IngestionHostedService> logger)
    : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            await ingestion.IngestAsync(force: false, stoppingToken);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError(ex, "Startup ingestion failed. Check Qdrant and Azure OpenAI settings, then call POST /api/ingest.");
        }
    }
}
