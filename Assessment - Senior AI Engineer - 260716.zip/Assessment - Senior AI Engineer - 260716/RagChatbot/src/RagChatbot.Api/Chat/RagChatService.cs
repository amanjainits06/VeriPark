using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.AzureOpenAI;
using RagChatbot.Api.Options;
using RagChatbot.Api.Retrieval;

namespace RagChatbot.Api.Chat;

public sealed record SourceReference(int Page, double Score, string Snippet);

public sealed record ChatResult(string SessionId, string Answer, IReadOnlyList<SourceReference> Sources);

public sealed class RagChatService(
    Kernel kernel,
    IDocumentRetriever retriever,
    ChatSessionStore sessions,
    IOptions<AzureOpenAIOptions> openAiOptions)
{
    private readonly IChatCompletionService _chat = kernel.GetRequiredService<IChatCompletionService>();
    private readonly AzureOpenAIPromptExecutionSettings _settings = new()
    {
        ReasoningEffort = openAiOptions.Value.ReasoningEffort
    };

    public async Task<ChatResult> AskAsync(string? sessionId, string message, CancellationToken ct = default)
    {
        sessionId = string.IsNullOrWhiteSpace(sessionId) ? Guid.NewGuid().ToString("N") : sessionId;
        var session = sessions.GetOrCreate(sessionId);
        var turns = session.Snapshot();

        var searchQuery = await CondenseAsync(turns, message, ct);
        var chunks = await retriever.RetrieveAsync(searchQuery, ct);

        var history = new ChatHistory(Prompts.System);
        foreach (var turn in turns)
        {
            history.AddUserMessage(turn.User);
            history.AddAssistantMessage(turn.Assistant);
        }
        history.AddUserMessage(BuildGroundedMessage(message, chunks));

        var reply = await _chat.GetChatMessageContentAsync(history, _settings, kernel, ct);
        var answer = reply.Content?.Trim() ?? "";

        // Only the raw question is stored; excerpts are re-retrieved on every turn.
        session.Add(message, answer);

        var sources = chunks
            .Select(c => new SourceReference(c.Page, Math.Round(c.Score, 3), Snippet(c.Text)))
            .ToList();
        return new ChatResult(sessionId, answer, sources);
    }

    private async Task<string> CondenseAsync(IReadOnlyList<Turn> turns, string message, CancellationToken ct)
    {
        if (turns.Count == 0) return message;

        var transcript = new StringBuilder();
        foreach (var turn in turns)
            transcript.AppendLine($"User: {turn.User}").AppendLine($"Assistant: {turn.Assistant}");

        var history = new ChatHistory(Prompts.Condense);
        history.AddUserMessage($"Conversation history:\n{transcript}\nLatest message: {message}");

        var result = await _chat.GetChatMessageContentAsync(history, _settings, kernel, ct);
        return string.IsNullOrWhiteSpace(result.Content) ? message : result.Content.Trim();
    }

    private static string BuildGroundedMessage(string question, IReadOnlyList<RetrievedChunk> chunks)
    {
        var sb = new StringBuilder("Document excerpts:\n");
        if (chunks.Count == 0)
            sb.AppendLine("(no relevant excerpts found)");
        foreach (var chunk in chunks)
            sb.AppendLine($"[Page {chunk.Page}]\n{chunk.Text}\n");

        sb.AppendLine("Question:").Append(question);
        return sb.ToString();
    }

    private static string Snippet(string text) =>
        text.Length <= 200 ? text : text[..200] + "...";
}
