using System.Collections.Concurrent;

namespace RagChatbot.Api.Chat;

public sealed record Turn(string User, string Assistant);

public sealed class ChatSession(int maxTurns)
{
    private readonly object _lock = new();
    private readonly List<Turn> _turns = [];

    public IReadOnlyList<Turn> Snapshot()
    {
        lock (_lock) return _turns.ToList();
    }

    // Oldest turns are dropped first once the cap is exceeded.
    public void Add(string user, string assistant)
    {
        lock (_lock)
        {
            _turns.Add(new Turn(user, assistant));
            while (_turns.Count > maxTurns)
                _turns.RemoveAt(0);
        }
    }
}

public sealed class ChatSessionStore(int maxTurns)
{
    private readonly ConcurrentDictionary<string, ChatSession> _sessions = new();

    public ChatSession GetOrCreate(string sessionId) =>
        _sessions.GetOrAdd(sessionId, _ => new ChatSession(maxTurns));

    public bool Remove(string sessionId) => _sessions.TryRemove(sessionId, out _);
}
