using Microsoft.Extensions.AI;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.VectorData;
using Qdrant.Client;
using RagChatbot.Api.Options;

namespace RagChatbot.Api.Ingestion;

public sealed class IngestionService(
    PdfTextExtractor extractor,
    VectorStoreCollection<Guid, DocumentChunk> collection,
    QdrantClient qdrant,
    IEmbeddingGenerator<string, Embedding<float>> embeddings,
    IOptions<RagOptions> ragOptions,
    IOptions<QdrantOptions> qdrantOptions,
    ILogger<IngestionService> logger)
{
    private readonly RagOptions _rag = ragOptions.Value;
    private readonly SemaphoreSlim _gate = new(1, 1);

    /// <summary>Indexes the PDF. Skips when the collection is already populated unless <paramref name="force"/> is set.</summary>
    public async Task<int> IngestAsync(bool force, CancellationToken ct = default)
    {
        await _gate.WaitAsync(ct);
        try
        {
            if (force)
                await collection.EnsureCollectionDeletedAsync(ct);

            await collection.EnsureCollectionExistsAsync(ct);

            var existing = (int)await qdrant.CountAsync(qdrantOptions.Value.Collection, cancellationToken: ct);
            if (existing > 0)
            {
                logger.LogInformation("Collection already holds {Count} chunks; skipping ingestion.", existing);
                return existing;
            }

            var pages = extractor.Extract(Path.GetFullPath(_rag.PdfPath));
            var chunks = new RecursiveTextSplitter(_rag.ChunkSize, _rag.ChunkOverlap).Split(pages);
            logger.LogInformation("Extracted {Pages} pages into {Chunks} chunks.", pages.Count, chunks.Count);

            foreach (var batch in chunks.Chunk(_rag.EmbeddingBatchSize))
            {
                var vectors = await embeddings.GenerateAsync(batch.Select(c => c.Text).ToList(), cancellationToken: ct);
                var records = batch.Select((c, i) => new DocumentChunk
                {
                    Id = StableId(c),
                    Text = c.Text,
                    Page = c.Page,
                    ChunkIndex = c.Index,
                    Embedding = vectors[i].Vector
                }).ToList();

                await collection.UpsertAsync(records, ct);
            }

            logger.LogInformation("Ingestion complete: {Count} chunks stored.", chunks.Count);
            return chunks.Count;
        }
        finally
        {
            _gate.Release();
        }
    }

    private static Guid StableId(TextChunk chunk)
    {
        var hash = System.Security.Cryptography.MD5.HashData(
            System.Text.Encoding.UTF8.GetBytes($"{chunk.Page}:{chunk.Index}:{chunk.Text}"));
        return new Guid(hash);
    }
}
