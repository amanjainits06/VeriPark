namespace RagChatbot.Api.Ingestion;

/// <summary>Recursive splitter: paragraph, then line, then sentence, then word boundaries.</summary>
public sealed class RecursiveTextSplitter(int chunkSize, int chunkOverlap)
{
    private static readonly string[] Separators = ["\n\n", "\n", ". ", " "];

    private readonly int _chunkSize = chunkSize > 0
        ? chunkSize
        : throw new ArgumentOutOfRangeException(nameof(chunkSize));

    private readonly int _overlap = chunkOverlap >= 0 && chunkOverlap < chunkSize
        ? chunkOverlap
        : throw new ArgumentOutOfRangeException(nameof(chunkOverlap), "Overlap must be >= 0 and < chunk size.");

    public IReadOnlyList<TextChunk> Split(IEnumerable<PageText> pages)
    {
        var chunks = new List<TextChunk>();
        foreach (var page in pages)
            foreach (var text in Split(page.Text))
                chunks.Add(new TextChunk(page.Page, chunks.Count, text));
        return chunks;
    }

    public IReadOnlyList<string> Split(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return [];

        var pieces = new List<string>();
        SplitRecursive(text.Replace("\r\n", "\n"), 0, pieces);
        return Merge(pieces);
    }

    private void SplitRecursive(string text, int separatorIndex, List<string> output)
    {
        if (text.Length <= _chunkSize)
        {
            output.Add(text);
            return;
        }

        if (separatorIndex >= Separators.Length)
        {
            // No separator left: hard cut.
            for (var i = 0; i < text.Length; i += _chunkSize)
                output.Add(text.Substring(i, Math.Min(_chunkSize, text.Length - i)));
            return;
        }

        var separator = Separators[separatorIndex];
        var start = 0;
        while (start < text.Length)
        {
            var idx = text.IndexOf(separator, start, StringComparison.Ordinal);
            var end = idx < 0 ? text.Length : idx + separator.Length;
            SplitRecursive(text[start..end], separatorIndex + 1, output);
            start = end;
        }
    }

    private List<string> Merge(List<string> pieces)
    {
        var chunks = new List<string>();
        var current = new List<string>();
        var currentLength = 0;

        void Flush()
        {
            var chunk = string.Concat(current).Trim();
            if (chunk.Length > 0) chunks.Add(chunk);
        }

        foreach (var piece in pieces)
        {
            if (currentLength + piece.Length > _chunkSize && current.Count > 0)
            {
                Flush();

                // Keep trailing pieces up to the overlap size as the start of the next chunk.
                while (current.Count > 0 && (currentLength > _overlap || currentLength + piece.Length > _chunkSize))
                {
                    currentLength -= current[0].Length;
                    current.RemoveAt(0);
                }
            }

            current.Add(piece);
            currentLength += piece.Length;
        }

        if (current.Count > 0) Flush();
        return chunks;
    }
}
