using UglyToad.PdfPig;
using UglyToad.PdfPig.DocumentLayoutAnalysis.TextExtractor;

namespace RagChatbot.Api.Ingestion;

public sealed record PageText(int Page, string Text);

public sealed class PdfTextExtractor
{
    public IReadOnlyList<PageText> Extract(string path)
    {
        if (!File.Exists(path))
            throw new FileNotFoundException($"PDF not found: {path}", path);

        using var doc = PdfDocument.Open(path);
        var pages = new List<PageText>();
        foreach (var page in doc.GetPages())
        {
            var text = ContentOrderTextExtractor.GetText(page)?.Trim();
            if (!string.IsNullOrWhiteSpace(text))
                pages.Add(new PageText(page.Number, text));
        }
        return pages;
    }
}
