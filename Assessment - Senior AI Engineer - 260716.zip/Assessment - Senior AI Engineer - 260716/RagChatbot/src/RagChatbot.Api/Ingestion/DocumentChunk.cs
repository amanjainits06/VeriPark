using Microsoft.Extensions.VectorData;

namespace RagChatbot.Api.Ingestion;

public sealed class DocumentChunk
{
    [VectorStoreKey]
    public Guid Id { get; set; }

    [VectorStoreData]
    public string Text { get; set; } = "";

    [VectorStoreData]
    public int Page { get; set; }

    [VectorStoreData]
    public int ChunkIndex { get; set; }

    // Dimensions must match the embedding model (ada-002 = 1536).
    [VectorStoreVector(1536, DistanceFunction = DistanceFunction.CosineSimilarity)]
    public ReadOnlyMemory<float> Embedding { get; set; }
}

public sealed record TextChunk(int Page, int Index, string Text);
