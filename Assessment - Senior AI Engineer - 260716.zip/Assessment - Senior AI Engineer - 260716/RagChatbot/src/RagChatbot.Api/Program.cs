using RagChatbot.Api;
using RagChatbot.Api.Chat;
using RagChatbot.Api.Ingestion;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRagChatbot(builder.Configuration);

var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

app.MapPost("/api/chat", async (ChatRequest request, RagChatService chat, CancellationToken ct) =>
{
    if (string.IsNullOrWhiteSpace(request.Message))
        return Results.BadRequest(new { error = "message is required." });

    var result = await chat.AskAsync(request.SessionId, request.Message, ct);
    return Results.Ok(result);
});

app.MapDelete("/api/chat/{sessionId}", (string sessionId, ChatSessionStore store) =>
    store.Remove(sessionId) ? Results.NoContent() : Results.NotFound());

app.MapPost("/api/ingest", async (IngestionService ingestion, CancellationToken ct) =>
    Results.Ok(new { chunks = await ingestion.IngestAsync(force: true, ct) }));

app.Run();

public sealed record ChatRequest(string? SessionId, string Message);

public partial class Program;
