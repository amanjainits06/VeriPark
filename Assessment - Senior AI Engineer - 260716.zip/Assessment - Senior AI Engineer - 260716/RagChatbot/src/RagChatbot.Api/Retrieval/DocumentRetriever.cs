using Microsoft.Extensions.AI;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.VectorData;
using RagChatbot.Api.Ingestion;
using RagChatbot.Api.Options;

namespace RagChatbot.Api.Retrieval;

public sealed record RetrievedChunk(int Page, string Text, double Score);

public interface IDocumentRetriever
{
    Task<IReadOnlyList<RetrievedChunk>> RetrieveAsync(string query, CancellationToken ct = default);
}

public sealed class QdrantDocumentRetriever(
    VectorStoreCollection<Guid, DocumentChunk> collection,
    IEmbeddingGenerator<string, Embedding<float>> embeddings,
    IOptions<RagOptions> options) : IDocumentRetriever
{
    private readonly RagOptions _options = options.Value;

    public async Task<IReadOnlyList<RetrievedChunk>> RetrieveAsync(string query, CancellationToken ct = default)
    {
        var queryVector = (await embeddings.GenerateAsync(query, cancellationToken: ct)).Vector;

        var results = new List<RetrievedChunk>();
        await foreach (var hit in collection.SearchAsync(queryVector, _options.TopK, cancellationToken: ct))
        {
            var score = hit.Score ?? 0;
            if (score >= _options.MinScore)
                results.Add(new RetrievedChunk(hit.Record.Page, hit.Record.Text, score));
        }
        return results;
    }
}
