# Copilot Studio Licensing Guide - RAG Chatbot

A multi-turn chatbot that answers questions about the *Microsoft Copilot Studio Licensing Guide* PDF using Retrieval-Augmented Generation (RAG).

Built with C# / .NET 10, ASP.NET Core Minimal API, Semantic Kernel, Qdrant (local vector database) and Azure OpenAI.

## How it works

```mermaid
flowchart LR
    PDF[PDF] --> X[PdfPig page text] --> S[Recursive splitter] --> E[Azure OpenAI embeddings] --> Q[(Qdrant)]
    U[User] -->|POST /api/chat| API[Minimal API] --> R[RagChatService]
    R -->|1. condense follow-up| LLM[Azure OpenAI chat]
    R -->|2. embed + top-K search| Q
    R -->|3. grounded prompt + history| LLM
```

1. **Ingestion (at startup):** the PDF is read page by page, split into chunks, embedded with Azure OpenAI and stored in Qdrant. This is skipped when the collection already has data.
2. **Each question:** if there is chat history, the model first rewrites the follow-up into a standalone question. The question is embedded, and the 5 most similar chunks are fetched from Qdrant.
3. **Answer:** the model answers only from those chunks plus the conversation history, and cites pages as `(p. N)`. If the document does not contain the answer, it says so.

| Folder | Responsibility |
|---|---|
| `src/RagChatbot.Api/Ingestion/` | PDF extraction, recursive splitting, embedding and upsert into Qdrant |
| `src/RagChatbot.Api/Retrieval/` | Retriever over the Semantic Kernel vector store abstraction |
| `src/RagChatbot.Api/Chat/` | `RagChatService` (Semantic Kernel chat completion and `ChatHistory`), session memory, prompts |
| `src/RagChatbot.Api/Options/` | Strongly typed, validated configuration |
| `src/RagChatbot.Api/wwwroot/` | Simple chat web page |
| `tests/` | xUnit tests |
| `scripts/` | Script that asks the 7 assessment questions and writes `assessment_answers.md` |

## What you need

| Requirement | Notes |
|---|---|
| .NET 10 SDK | https://dotnet.microsoft.com/download (check with `dotnet --version`) |
| Qdrant | Either Docker (recommended) or the native Qdrant binary from the [Qdrant releases](https://github.com/qdrant/qdrant/releases) |
| Azure OpenAI resource | Two deployments: a chat model (for example `gpt-5-nano`) and an embedding model (`text-embedding-ada-002`, 1536 dimensions) |
| Azure OpenAI endpoint and API key | From the Azure portal: your resource, then *Keys and Endpoint* |
| PowerShell | Only to run `scripts/run-questions.ps1` |

Only Azure OpenAI is a cloud dependency. The vector store and the app run on your machine.

## Run it

All commands are run from the repository root.

### 1. Start Qdrant

With Docker (Docker Desktop must be running):

```powershell
docker compose up -d
```

Without Docker, download `qdrant-x86_64-pc-windows-msvc.zip` from the Qdrant releases page, unzip it and run `qdrant.exe` in its own terminal. Leave it running.

Check it is up: http://localhost:6333/dashboard (or `curl http://localhost:6333/healthz`).

### 2. Configure Azure OpenAI

Secrets are not stored in the repository. Set them with .NET user-secrets (stored in your user profile, outside the project):

```powershell
cd src/RagChatbot.Api
dotnet user-secrets set "AzureOpenAI:Endpoint" "https://<your-resource>.openai.azure.com/"
dotnet user-secrets set "AzureOpenAI:ApiKey" "<your-key>"
cd ../..
```

If your deployment names differ from `gpt-5-nano` and `text-embedding-ada-002`, also set:

```powershell
cd src/RagChatbot.Api
dotnet user-secrets set "AzureOpenAI:DeploymentName" "<your-chat-deployment>"
dotnet user-secrets set "AzureOpenAI:EmbeddingDeploymentName" "<your-embedding-deployment>"
cd ../..
```

Alternative: environment variables (see `.env.example`), for example in PowerShell:

```powershell
$env:AzureOpenAI__Endpoint = "https://<your-resource>.openai.azure.com/"
$env:AzureOpenAI__ApiKey = "<your-key>"
```

If `ApiKey` is empty, the app falls back to `DefaultAzureCredential` (Entra ID sign-in, for example `az login`).

### 3. Start the app

```powershell
dotnet run --project src/RagChatbot.Api
```

On the first start the PDF is indexed (about 47 chunks). Wait for the log line `Ingestion complete` (later starts show `skipping ingestion`).

### 4. Chat

Open http://localhost:5080 and ask questions. Follow-ups such as "compare it with the previous option" work because the chat history is kept per session.

Or call the API:

```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:5080/api/chat -ContentType "application/json" `
  -Body '{"message":"What is a Copilot Credit?"}'
```

### 5. (Optional) Regenerate the assessment answers

With the app running:

```powershell
./scripts/run-questions.ps1
```

This sends the 7 assessment questions to the chatbot in one session and writes `assessment_answers.md`. Question 7 relies on the chatbot's conversation memory.

## API

| Method | Path | Description |
|---|---|---|
| POST | `/api/chat` | Body `{ "sessionId": "optional", "message": "..." }`. Returns `{ sessionId, answer, sources[] }`. Reuse the returned `sessionId` for follow-ups. |
| DELETE | `/api/chat/{sessionId}` | Clear a session's history |
| POST | `/api/ingest` | Drop and rebuild the Qdrant index |
| GET | `/health` | Liveness check |

The API is plain REST/JSON. The app talks to Qdrant over gRPC (port 6334) and to Azure OpenAI over HTTPS.

## Design choices

**Chunking**
- PdfPig reads the PDF page by page, so every chunk keeps its page number for citations.
- A recursive splitter (paragraph, then line, then sentence, then word) avoids cutting prices or definitions in half. The guide mixes prose, bullets and tables.
- 1000 characters (about 200-250 tokens) is large enough for a complete idea and small enough that the top 5 chunks stay focused.
- 150 characters of overlap (about 15%) keeps facts that straddle a boundary whole in at least one chunk.

**Conversation memory**
- History is kept in memory per `sessionId`: the last 10 turns (question and answer pairs). When the limit is reached, the oldest turn is dropped first. The system prompt is never dropped. History is lost when the app restarts.
- Only the question and answer are stored. The document excerpts are fetched again on every turn.

## Configuration reference

| Key | Default | Description |
|---|---|---|
| `AzureOpenAI:Endpoint` | empty | Azure OpenAI endpoint (required, set via secrets) |
| `AzureOpenAI:ApiKey` | empty | API key (set via secrets; empty means Entra ID) |
| `AzureOpenAI:DeploymentName` | `gpt-5-nano` | Chat deployment |
| `AzureOpenAI:EmbeddingDeploymentName` | `text-embedding-ada-002` | Embedding deployment |
| `AzureOpenAI:ReasoningEffort` | `low` | For reasoning models (`minimal`, `low`, `medium`, `high`) |
| `Qdrant:Host` / `GrpcPort` / `Collection` | `localhost` / `6334` / `copilot_studio_licensing_guide` | Qdrant connection |
| `Rag:PdfPath` | `Data/Microsoft-Copilot-Studio-Licensing-Guide.pdf` | Document to index |
| `Rag:ChunkSize` / `ChunkOverlap` | `1000` / `150` | Chunking (characters) |
| `Rag:TopK` / `MinScore` | `5` / `0.7` | Retrieval count and minimum cosine score |
| `Rag:MaxHistoryTurns` | `10` | Turns kept per session |

The embedding vector size (1536) is fixed in `DocumentChunk`. If you switch to another embedding model, change it there and call `POST /api/ingest`.

## Tests

```powershell
dotnet test
```

Covers the splitter (size, overlap, page numbers), session trimming, and extraction and chunking of the real PDF. No Azure or Qdrant access is needed.

## Troubleshooting

| Problem | Fix |
|---|---|
| `docker compose` fails with "cannot connect" or "pipe docker_engine not found" | Start Docker Desktop, wait until it says it is running, then retry. Or use the native Qdrant binary. |
| Startup log: `Startup ingestion failed` | Qdrant is not running on port 6334, or the Azure settings are wrong. Fix, then call `POST /api/ingest`. |
| App fails at startup with a validation error about `Endpoint` | The user-secrets or environment variables are not set (step 2). |
| `401` / `PermissionDenied` from Azure | Wrong or expired API key, or the key belongs to a different resource. |
| `404 DeploymentNotFound` from Azure | The deployment name does not match a deployment in your resource. Set `DeploymentName` and `EmbeddingDeploymentName`. |
| Answers say "I could not find this in the Copilot Studio Licensing Guide" | The question is outside the document, or `MinScore` is too high. Try lowering `Rag:MinScore`. |
| Port 5080 already in use | Change `applicationUrl` in `src/RagChatbot.Api/Properties/launchSettings.json`. |

## Security notes

- Never commit API keys. Secrets belong in user-secrets or environment variables. `.env`, `secrets.json` and local settings files are git-ignored.
- If a key was ever pasted into a file, chat or a commit, rotate it in the Azure portal.
- The chat endpoints have no authentication. Run the app on localhost only, and add authentication before exposing it.
